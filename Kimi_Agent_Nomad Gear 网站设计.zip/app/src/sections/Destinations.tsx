import { useRef, useEffect, useState } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { MapPin, ArrowRight, X } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const destinations = [
  {
    id: 1,
    img: '/images/dest-1.jpg',
    name: 'Emerald Lake',
    location: 'Banff National Park, Canada',
    description: 'Crystal-clear alpine waters surrounded by towering pines and snow-capped peaks. Perfect for kayaking and lakeside camping.',
    price: '$85/night',
    rating: '4.9',
    terrain: 'Alpine / Lakeside',
  },
  {
    id: 2,
    img: '/images/dest-2.jpg',
    name: 'Red Rock Canyon',
    location: 'Moab, Utah',
    description: 'Dramatic sandstone formations and desert vistas. Experience the raw beauty of the American Southwest under star-filled skies.',
    price: '$65/night',
    rating: '4.8',
    terrain: 'Desert / Canyon',
  },
  {
    id: 3,
    img: '/images/dest-3.jpg',
    name: 'Misty Pines Grove',
    location: 'Olympic National Park, WA',
    description: 'Enchanted old-growth forest with morning mist and fairy-light canopies. A magical retreat for forest bathing enthusiasts.',
    price: '$75/night',
    rating: '4.9',
    terrain: 'Forest / Temperate',
  },
  {
    id: 4,
    img: '/images/dest-4.jpg',
    name: 'Cliffside Haven',
    location: 'Big Sur, California',
    description: 'Perched above the Pacific with panoramic ocean views. Fall asleep to the sound of crashing waves and coastal breezes.',
    price: '$95/night',
    rating: '5.0',
    terrain: 'Coastal / Cliff',
  },
];

export default function Destinations() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const [selectedDest, setSelectedDest] = useState<typeof destinations[0] | null>(null);

  useEffect(() => {
    const section = sectionRef.current;
    const scrollContainer = scrollContainerRef.current;
    if (!section || !scrollContainer) return;

    const ctx = gsap.context(() => {
      // Horizontal scroll
      const scrollWidth = scrollContainer.scrollWidth - window.innerWidth;

      gsap.to(scrollContainer, {
        x: -scrollWidth,
        ease: 'none',
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: () => `+=${scrollWidth}`,
          scrub: 1,
          pin: true,
          anticipatePin: 1,
        },
      });
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <>
      <section
        ref={sectionRef}
        id="destinations"
        className="relative overflow-hidden"
        style={{ backgroundColor: '#0e0d0d' }}
      >
        {/* Section header */}
        <div className="absolute top-0 left-0 right-0 z-20 pt-10 px-8 lg:px-16">
          <span className="font-sans uppercase text-xs tracking-[3px] font-semibold" style={{ color: '#ddfc74' }}>
            Destination Inspiration
          </span>
          <h2
            className="font-serif font-bold mt-2 text-nomad-parchment"
            style={{ fontSize: 'clamp(32px, 4vw, 56px)', letterSpacing: '-2px' }}
          >
            Find Your Basecamp
          </h2>
        </div>

        {/* Horizontal scrolling container */}
        <div
          ref={scrollContainerRef}
          className="flex items-center gap-6 lg:gap-8 h-screen pl-8 lg:pl-16 pr-[30vw]"
          style={{ paddingTop: 140 }}
        >
          {destinations.map((dest) => (
            <div
              key={dest.id}
              className="group relative flex-shrink-0 cursor-pointer"
              style={{ width: 'clamp(300px, 35vw, 500px)' }}
              onClick={() => setSelectedDest(dest)}
            >
              {/* Polaroid-style card */}
              <div
                className="relative overflow-hidden rounded-2xl transition-all duration-500 group-hover:-translate-y-3"
                style={{
                  backgroundColor: '#ffffff',
                  padding: '12px 12px 0 12px',
                  boxShadow: '0 20px 60px rgba(0,0,0,0.3)',
                }}
              >
                <div className="relative overflow-hidden rounded-xl" style={{ aspectRatio: '16/10' }}>
                  <img
                    src={dest.img}
                    alt={dest.name}
                    loading="lazy"
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />

                  {/* Quick View button */}
                  <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-500">
                    <span
                      className="font-sans text-xs uppercase tracking-[2px] font-semibold px-5 py-2.5 rounded-pill"
                      style={{ backgroundColor: '#ddfc74', color: '#0e0d0d' }}
                    >
                      Quick View
                    </span>
                  </div>
                </div>

                {/* Card info */}
                <div className="p-4">
                  <div className="flex items-center gap-1.5 text-nomad-stone mb-1">
                    <MapPin size={12} />
                    <span className="font-sans text-[11px] uppercase tracking-[1px]">{dest.location}</span>
                  </div>
                  <h4 className="font-serif text-xl font-bold text-nomad-charcoal">{dest.name}</h4>
                  <div className="flex items-center justify-between mt-3">
                    <span className="font-sans text-sm font-semibold text-nomad-sage">{dest.price}</span>
                    <span className="font-sans text-xs text-nomad-stone">{dest.rating} ★</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Scroll hint */}
        <div className="absolute bottom-8 right-8 z-20 flex items-center gap-2 text-nomad-parchment/40">
          <span className="font-sans text-[11px] uppercase tracking-[2px]">Scroll to explore</span>
          <ArrowRight size={14} />
        </div>
      </section>

      {/* Modal */}
      {selectedDest && (
        <div
          className="fixed inset-0 z-[100] flex items-center justify-center p-4"
          onClick={() => setSelectedDest(null)}
        >
          {/* Backdrop */}
          <div className="absolute inset-0 bg-nomad-charcoal/80 backdrop-blur-sm" />

          {/* Modal content */}
          <div
            className="relative z-10 w-full max-w-2xl rounded-2xl overflow-hidden"
            style={{
              backgroundColor: '#ffffff',
              boxShadow: '0 24px 24px rgba(0,0,0,0.08), 0 0 24px rgba(0,0,0,0.04)',
            }}
            onClick={(e) => e.stopPropagation()}
          >
            {/* Close button */}
            <button
              onClick={() => setSelectedDest(null)}
              className="absolute top-4 right-4 z-20 w-10 h-10 rounded-full flex items-center justify-center transition-colors duration-300"
              style={{ backgroundColor: 'rgba(14,13,13,0.6)' }}
            >
              <X size={18} className="text-white" />
            </button>

            <div className="relative" style={{ aspectRatio: '16/9' }}>
              <img src={selectedDest.img} alt={selectedDest.name} className="w-full h-full object-cover" />
            </div>

            <div className="p-6 lg:p-8">
              <div className="flex items-center gap-1.5 text-nomad-stone mb-2">
                <MapPin size={14} />
                <span className="font-sans text-xs uppercase tracking-[1.5px]">{selectedDest.location}</span>
              </div>

              <h3 className="font-serif text-3xl font-bold text-nomad-charcoal">{selectedDest.name}</h3>

              <p className="font-sans text-sm text-nomad-stone mt-3 leading-relaxed">
                {selectedDest.description}
              </p>

              <div className="flex items-center gap-4 mt-4">
                <span className="font-sans text-xs uppercase tracking-[1px] px-3 py-1 rounded-pill bg-nomad-parchment text-nomad-charcoal">
                  {selectedDest.terrain}
                </span>
                <span className="font-sans text-sm font-semibold text-nomad-sage">
                  {selectedDest.price}
                </span>
              </div>

              <button
                className="mt-6 w-full py-4 rounded-pill font-sans font-semibold text-sm transition-transform duration-300 hover:scale-[1.02]"
                style={{ backgroundColor: '#ddfc74', color: '#0e0d0d' }}
              >
                Reserve This Spot
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
