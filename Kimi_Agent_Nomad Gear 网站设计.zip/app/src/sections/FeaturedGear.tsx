import { useRef, useEffect } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const gearItems = [
  { id: 1, img: '/images/catalog-1.jpg', title: 'Alpine Pro Tent', price: '$45/day', tag: 'Best Seller' },
  { id: 2, img: '/images/catalog-2.jpg', title: 'Summit 65L Pack', price: '$28/day', tag: 'New' },
  { id: 3, img: '/images/catalog-3.jpg', title: 'Trailbreaker Boots', price: '$22/day', tag: '' },
  { id: 4, img: '/images/catalog-4.jpg', title: 'Camp Kitchen Set', price: '$18/day', tag: 'Bundle' },
  { id: 5, img: '/images/catalog-5.jpg', title: 'Forest Haven Kit', price: '$65/day', tag: 'Popular' },
  { id: 6, img: '/images/catalog-6.jpg', title: 'Peak Finder Guide', price: '$12/day', tag: '' },
  { id: 7, img: '/images/catalog-7.jpg', title: 'Brass Compass', price: '$8/day', tag: '' },
  { id: 8, img: '/images/catalog-8.jpg', title: 'Cave Explorer Light', price: '$15/day', tag: 'LED' },
  { id: 9, img: '/images/catalog-9.jpg', title: 'Arctic Down Bag', price: '$32/day', tag: 'Winter' },
  { id: 10, img: '/images/catalog-10.jpg', title: 'Titanium Flask', price: '$10/day', tag: '' },
  { id: 11, img: '/images/catalog-11.jpg', title: 'Multi-Tool Pro', price: '$14/day', tag: '' },
  { id: 12, img: '/images/catalog-12.jpg', title: 'Autumn Trek Pass', price: '$50/day', tag: 'Seasonal' },
];

export default function FeaturedGear() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const gridRef = useRef<HTMLDivElement>(null);
  const titleRef = useRef<HTMLDivElement>(null);
  const itemRefs = useRef<(HTMLDivElement | null)[]>([]);

  useEffect(() => {
    const section = sectionRef.current;
    const grid = gridRef.current;
    if (!section || !grid) return;

    const ctx = gsap.context(() => {
      // Sticky title scale
      if (titleRef.current) {
        gsap.fromTo(
          titleRef.current,
          { scale: 0.8, opacity: 0.3 },
          {
            scale: 1.2,
            opacity: 1,
            ease: 'none',
            scrollTrigger: {
              trigger: section,
              start: 'top bottom',
              end: 'bottom top',
              scrub: true,
            },
          }
        );
      }

      // Individual card parallax
      itemRefs.current.forEach((item, i) => {
        if (!item) return;
        const isLeft = (i % 4) < 2;
        const direction = isLeft ? -40 : 40;
        const rot = isLeft ? -3 : 3;

        gsap.fromTo(
          item,
          { y: 80, opacity: 0, rotateZ: rot * 0.5 },
          {
            y: 0,
            opacity: 1,
            rotateZ: 0,
            duration: 0.8,
            ease: 'power2.out',
            scrollTrigger: {
              trigger: item,
              start: 'top 90%',
              toggleActions: 'play none none reverse',
            },
          }
        );

        // Parallax on scroll
        gsap.to(item, {
          xPercent: direction * 0.3,
          ease: 'none',
          scrollTrigger: {
            trigger: item,
            start: 'top bottom',
            end: 'bottom top',
            scrub: true,
          },
        });
      });
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="collection"
      className="relative"
      style={{ backgroundColor: '#f1f0ec', paddingTop: 100, paddingBottom: 100 }}
    >
      {/* Sticky overlay title */}
      <div
        ref={titleRef}
        className="sticky top-1/2 -translate-y-1/2 z-20 pointer-events-none text-center"
        style={{ mixBlendMode: 'exclusion' }}
      >
        <h2
          className="font-serif font-bold uppercase text-nomad-white tracking-[6px]"
          style={{ fontSize: 'clamp(40px, 6vw, 72px)', letterSpacing: '6px' }}
        >
          The Collection
        </h2>
      </div>

      {/* Section header */}
      <div className="text-center mb-16 px-6 relative z-10">
        <span className="font-sans uppercase text-xs tracking-[3px] text-nomad-sage font-semibold">
          Featured Gear
        </span>
        <h3
          className="font-serif font-bold mt-3 text-nomad-charcoal"
          style={{ fontSize: 'clamp(32px, 4vw, 56px)', letterSpacing: '-1.5px' }}
        >
          Ready for the Wild
        </h3>
      </div>

      {/* Grid */}
      <div
        ref={gridRef}
        className="max-w-[1400px] mx-auto px-4 lg:px-8 grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 lg:gap-5 relative z-10"
      >
        {gearItems.map((item, i) => (
          <div
            key={item.id}
            ref={(el) => { itemRefs.current[i] = el; }}
            className="group relative overflow-hidden rounded-2xl cursor-pointer"
            style={{ backgroundColor: '#ffffff' }}
          >
            {/* Image container */}
            <div className="relative overflow-hidden" style={{ aspectRatio: '3/4' }}>
              <img
                src={item.img}
                alt={item.title}
                loading="lazy"
                className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-110"
              />

              {/* Tag */}
              {item.tag && (
                <span
                  className="absolute top-3 left-3 font-sans text-[10px] uppercase tracking-[1.5px] font-semibold px-3 py-1 rounded-pill"
                  style={{ backgroundColor: '#ddfc74', color: '#0e0d0d' }}
                >
                  {item.tag}
                </span>
              )}

              {/* Hover overlay with Book Now */}
              <div className="absolute inset-0 bg-nomad-charcoal/0 group-hover:bg-nomad-charcoal/40 transition-all duration-500 flex items-center justify-center">
                <button
                  className="opacity-0 group-hover:opacity-100 translate-y-4 group-hover:translate-y-0 transition-all duration-500 font-sans text-sm font-semibold px-6 py-3 rounded-pill"
                  style={{ backgroundColor: '#ddfc74', color: '#0e0d0d' }}
                >
                  Book Now
                </button>
              </div>
            </div>

            {/* Info */}
            <div className="p-4">
              <h4 className="font-serif text-lg font-semibold text-nomad-charcoal leading-tight">
                {item.title}
              </h4>
              <p className="font-sans text-sm font-medium text-nomad-sage mt-1">
                {item.price}
              </p>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
