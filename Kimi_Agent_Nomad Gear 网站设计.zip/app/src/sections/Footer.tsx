export default function Footer() {
  const links = [
    {
      title: 'Rentals',
      items: ['How It Works', 'Pricing', 'Gear Guide', 'Insurance', 'Group Bookings'],
    },
    {
      title: 'Company',
      items: ['About Us', 'Sustainability', 'Careers', 'Press', 'Blog'],
    },
    {
      title: 'Support',
      items: ['Help Center', 'Contact Us', 'Shipping', 'Returns', 'FAQ'],
    },
    {
      title: 'Legal',
      items: ['Terms of Service', 'Privacy Policy', 'Cookie Policy', 'Rental Agreement'],
    },
  ];

  return (
    <footer
      id="footer"
      className="relative overflow-hidden"
      style={{ backgroundColor: '#0e0d0d', color: '#f1f0ec' }}
    >
      {/* Link columns */}
      <div className="max-w-[1400px] mx-auto px-6 lg:px-10 pt-20 pb-16">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-10 lg:gap-16">
          {links.map((group) => (
            <div key={group.title}>
              <h4 className="font-sans text-[11px] uppercase tracking-[2px] font-semibold text-nomad-parchment/50 mb-5">
                {group.title}
              </h4>
              <ul className="space-y-3">
                {group.items.map((item) => (
                  <li key={item}>
                    <a
                      href="#"
                      className="font-sans text-sm text-nomad-parchment/70 hover:text-nomad-chartreuse transition-colors duration-300"
                    >
                      {item}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Newsletter */}
        <div className="mt-16 pt-10 border-t border-nomad-parchment/10">
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
            <div>
              <h4 className="font-serif text-xl font-semibold text-nomad-parchment">Join the Expedition</h4>
              <p className="font-sans text-sm text-nomad-parchment/50 mt-1">
                Get gear guides, destination inspiration, and exclusive offers.
              </p>
            </div>
            <div className="flex gap-3 w-full md:w-auto">
              <input
                type="email"
                placeholder="your@email.com"
                className="flex-1 md:w-64 px-5 py-3 rounded-pill bg-nomad-obsidian border border-nomad-parchment/10 text-sm font-sans text-nomad-parchment placeholder:text-nomad-parchment/30 outline-none focus:border-nomad-sage transition-colors"
              />
              <button
                className="px-6 py-3 rounded-pill font-sans text-sm font-semibold transition-transform duration-300 hover:scale-105 flex-shrink-0"
                style={{ backgroundColor: '#ddfc74', color: '#0e0d0d' }}
              >
                Subscribe
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Giant logotype */}
      <div className="relative w-full overflow-hidden" style={{ height: 280 }}>
        <h2
          className="absolute bottom-0 left-1/2 -translate-x-1/2 font-serif font-bold uppercase text-nomad-parchment/[0.04] whitespace-nowrap select-none leading-none"
          style={{ fontSize: 'clamp(120px, 18vw, 280px)', letterSpacing: '20px' }}
        >
          NOMAD
        </h2>
      </div>

      {/* Bottom bar */}
      <div className="border-t border-nomad-parchment/10 py-6 px-6 lg:px-10">
        <div className="max-w-[1400px] mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="font-sans text-xs text-nomad-parchment/30">
            © 2026 Nomad Gear. All rights reserved. Leave no trace.
          </p>
          <div className="flex items-center gap-6">
            <a href="#" className="font-sans text-xs text-nomad-parchment/30 hover:text-nomad-parchment/60 transition-colors">
              Instagram
            </a>
            <a href="#" className="font-sans text-xs text-nomad-parchment/30 hover:text-nomad-parchment/60 transition-colors">
              Twitter
            </a>
            <a href="#" className="font-sans text-xs text-nomad-parchment/30 hover:text-nomad-parchment/60 transition-colors">
              YouTube
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
