import OrganicStratifiedField from '../components/OrganicStratifiedField';
import { ArrowRight } from 'lucide-react';

export default function Hero() {
  return (
    <section
      id="hero"
      className="relative w-full overflow-hidden"
      style={{ height: '100vh' }}
    >
      {/* WebGL Shader Background */}
      <OrganicStratifiedField />

      {/* Content */}
      <div className="relative z-10 flex flex-col items-center justify-center h-full text-center px-6">
        <h1
          className="font-serif font-bold text-nomad-parchment leading-[1.05] select-none"
          style={{
            fontSize: 'clamp(48px, 8vw, 88px)',
            letterSpacing: '-3.52px',
            textShadow: '0 4px 30px rgba(0,0,0,0.4)',
          }}
        >
          Explore the Horizon
        </h1>

        <p
          className="font-sans uppercase tracking-[3px] mt-5 text-nomad-parchment/70"
          style={{ fontSize: '13px', fontWeight: 500, letterSpacing: '3px' }}
        >
          Premium Gear. Zero Footprint.
        </p>

        {/* CTA Button */}
        <button
          className="group mt-10 relative overflow-hidden rounded-pill flex items-center gap-3 px-8 py-4 font-sans font-semibold text-sm animate-bob transition-transform duration-300 hover:scale-105"
          style={{ backgroundColor: '#ddfc74', color: '#0e0d0d' }}
        >
          <span className="relative z-10">Start Expedition</span>
          <ArrowRight size={16} className="relative z-10 transition-transform duration-300 group-hover:translate-x-1" />
        </button>
      </div>

      {/* Bottom gradient fade into next section */}
      <div
        className="absolute bottom-0 left-0 right-0 z-10 pointer-events-none"
        style={{
          height: 200,
          background: 'linear-gradient(to bottom, transparent, #f1f0ec)',
        }}
      />
    </section>
  );
}
