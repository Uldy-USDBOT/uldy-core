import { useRef, useEffect } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

export default function Manifesto() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const textRef = useRef<HTMLParagraphElement>(null);

  useEffect(() => {
    const el = textRef.current;
    if (!el) return;

    gsap.fromTo(
      el,
      { opacity: 0, y: 40 },
      {
        opacity: 1,
        y: 0,
        duration: 1.2,
        ease: 'power2.out',
        scrollTrigger: {
          trigger: el,
          start: 'top 80%',
          end: 'top 40%',
          toggleActions: 'play none none reverse',
        },
      }
    );

    return () => {
      ScrollTrigger.getAll().forEach((t) => t.kill());
    };
  }, []);

  return (
    <section
      ref={sectionRef}
      className="relative flex items-center justify-center"
      style={{
        minHeight: 400,
        backgroundColor: '#f1f0ec',
        padding: '80px 24px',
      }}
    >
      <p
        ref={textRef}
        className="font-serif text-center max-w-4xl mx-auto leading-[1.35]"
        style={{
          fontSize: 'clamp(24px, 4vw, 42px)',
          letterSpacing: '-1px',
          color: '#0e0d0d',
        }}
      >
        We curate the finest outdoor equipment so you can focus on the journey. Leave the logistics to us.
      </p>
    </section>
  );
}
