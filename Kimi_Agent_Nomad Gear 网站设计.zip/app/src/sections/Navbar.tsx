import { useRef, useState, useEffect } from 'react';
import { Search, ChevronDown, MapPin } from 'lucide-react';

export default function Navbar() {
  const navRef = useRef<HTMLElement>(null);
  const [hidden, setHidden] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const lastScrollY = useRef(0);

  useEffect(() => {
    const onScroll = () => {
      const y = window.scrollY;
      setScrolled(y > 50);
      if (y > lastScrollY.current && y > 100) {
        setHidden(true);
      } else {
        setHidden(false);
      }
      lastScrollY.current = y;
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <nav
      ref={navRef}
      className="fixed top-0 left-0 right-0 z-50 transition-all duration-500"
      style={{
        height: 80,
        backgroundColor: scrolled ? 'rgba(255,255,255,0.92)' : '#ffffff',
        backdropFilter: scrolled ? 'blur(20px)' : 'none',
        borderBottom: '1px solid #a39e97',
        transform: hidden ? 'translateY(-100%)' : 'translateY(0)',
      }}
    >
      <div className="max-w-[1400px] mx-auto h-full flex items-center justify-between px-6 lg:px-10">
        {/* Logo */}
        <a href="#" className="font-serif text-2xl lg:text-[28px] font-600 tracking-tight text-nomad-charcoal select-none">
          Nomad Gear
        </a>

        {/* Search Bar - hidden on mobile */}
        <div className="hidden md:flex items-center flex-1 max-w-md mx-8">
          <div
            className="w-full flex items-center gap-3 px-5 py-2.5 rounded-pill transition-shadow duration-300 focus-within:shadow-float"
            style={{ backgroundColor: '#ddfc74' }}
          >
            <Search size={16} className="text-nomad-charcoal opacity-60" />
            <input
              type="text"
              placeholder="Find tents, packs, or locations..."
              className="bg-transparent outline-none text-sm text-nomad-charcoal placeholder:text-nomad-charcoal/50 w-full font-sans"
            />
          </div>
        </div>

        {/* Right side */}
        <div className="flex items-center gap-3 lg:gap-5">
          <button className="hidden lg:flex items-center gap-1.5 text-sm font-sans font-medium text-nomad-charcoal/80 hover:text-nomad-charcoal transition-colors">
            Explore
            <ChevronDown size={14} />
          </button>

          <button className="hidden lg:flex items-center gap-1.5 text-sm font-sans font-medium text-nomad-charcoal/80 hover:text-nomad-charcoal transition-colors">
            <MapPin size={14} />
            National Park
            <ChevronDown size={14} />
          </button>

          {/* Book Now Button */}
          <button
            className="group relative overflow-hidden rounded-pill font-sans text-sm font-semibold transition-transform duration-300 hover:scale-105"
            style={{
              backgroundColor: '#0e0d0d',
              color: '#f1f0ec',
              padding: '10px 24px',
            }}
          >
            <span className="relative z-10">Book Now</span>
            <span
              className="absolute inset-0 rounded-pill transition-transform duration-600 scale-0 group-hover:scale-100"
              style={{ backgroundColor: '#ddfc74' }}
            />
            <span className="absolute inset-0 z-10 flex items-center justify-center text-nomad-charcoal opacity-0 group-hover:opacity-100 transition-opacity duration-300 font-semibold text-sm">
              Book Now
            </span>
          </button>
        </div>
      </div>
    </nav>
  );
}
